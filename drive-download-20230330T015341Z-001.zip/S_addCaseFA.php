<?php 
include 'misc/S_header.php'; 
$staff = new StaffView();

$staffInfo = $staff->displayClientID($_SESSION['clientID']);
$caseInfo = new StaffController();
$trigger = $caseInfo->staffAction();

$_SESSION['caseType'] = '2';
?>

<!-- Sweet Alert  -->
<?php if (isset($_SESSION['message'])) { ?>
    <script>
      swal({
          title: "<?php echo $_SESSION['title'] ?>",
          text: "<?php echo $_SESSION['message'] ?>",
          icon: "<?php echo $_SESSION['msg'] ?>",
          button: "OK!",
          timer: 3000,
      });
    </script>
   <?php
   unset($_SESSION['message']);
     } 
   ?>
   <!-- Sweet Alert End --> 

<div class="container-fluid">
    <div>        
        <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="S_Index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="S_caseStudy.php">Select Client</a></li>
            <li class="breadcrumb-item active" aria-current="page"><a href="S_caseStudies.php">Client Info</a></li>
            <li class="breadcrumb-item active" aria-current="page">Financial Assistance</li>
            </ol>
        </nav>
    </div>

    <div class="col-xl-12   ">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Add New Record</h6>
            </div>
            <h6 class="mx-3 mt-2 text-bold">II. Problem Presented</h6>
             <div class="card-body s">

            <form action="" method="post">
            
                <div class="form-group col-md-6">
                    <label for="fName">Client Code:</label>
                    <input class="form-control" type="hidden" name="getAssitantType" value="2" readonly> 
                    <input class="form-control" type="hidden" name="userCode" id="userCode" value="<?php echo $staffInfo['cCTR']; ?>" readonly> 
                    <input class="form-control" type="text" name="clientCode" id="clientCode" value="<?php echo $staffInfo['clientCode']; ?>" readonly> 
                </div>    
                <div class="form-group col-md-6">
                    <label for="fName">Full Name of Claimant:</label>
                <input class="form-control" type="text" name="clientFullName" id="clientFullName" value="<?php echo $staffInfo['firstName']; ?>, <?php echo $staffInfo['middleName']; ?>, <?php echo $staffInfo['lastName']; ?>" readonly> 
                </div>  
                <div class="form-group col-md-6">
                    <label for="fName">Amount Issued:</label>
                <input class="form-control" type="number" name="number" placeholder="Amount Issued:" required> 
                </div>

                <div class="form-group col-md-6">
                    <label for="fName">Pangalan ng lumapit?:</label>
                    <input class="form-control" type="text" name="problemPresented1" placeholder="Pangalan ng lumapit" required> 
                </div>

                <div class="form-group col-md-6">
                    <!-- <label for="mName">Anong klaseng Assistant (financial/medical)?:</label> -->
                    <input class="form-control" type="hidden" name="problemPresented2"  value="financial" required> 
                </div>

                <!-- <div class="form-group col-md-6">
            <label for="inputState"> Anong klaseng Assistance (financial/medical)?: </label>
            <select id="inputState" class="form-control" name="problemPresented2">
              <option disabled selected> --Select-- </option>
              <option value="financial"> financial </option>
              <option value="medical"> medical </option>
            </select>
          </div> -->

                <div class="form-group col-md-6">
                    <label for="lName">Para kanino ka lumalapit ng Assistance?:</label>
                    <input class="form-control" type="text" name="problemPresented3" placeholder="Para kanino ka lumalapit ng Assistant" required> 
                </div>
            
                <div class="form-group col-md-6">
                    <label for="fName">Kaano-ano ang pasyente?:</label>
                    <input class="form-control" type="text" name="problemPresented4" placeholder="Kaano-ano ang pasyente" required> 
                </div>
                <div class="form-group col-md-6">
                    <label for="mName">Ano ang karamdaman ng pasyente base sa kanyang medical certificate?:</label>
                    <input class="form-control" type="text" name="problemPresented5"  placeholder="karamdaman ng pasyente" required> 
                </div>
                <div class="form-group col-md-6">
                    <label for="lName">Para saan gagamitin ang assistance?:</label>
                    <input class="form-control" type="text" name="problemPresented6" placeholder="Para saan gagamitin ang assistance" required> 
                </div>
              
                <hr> 
        <h6 class="mx-3 mt-4 text-bold">III. Family Background(Pasyente)</h6>
        <div class="text-center">
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary mx-3" data-toggle="modal" data-target="#exampleModal2">
                Married
            </button>

            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary mx-3" data-toggle="modal" data-target="#exampleModal">
                Seperated
            </button>  
        
            <div class="card-body "> 

                <textarea name="familybackground" placeholder="Paste Here" id="" cols="90" rows="10" required></textarea>
            </div>
        </div>
        <div class="card-body text-center">
            <h6 class="m-0 font-weight-bold text-primary">Recommendation: </h6>
            <textarea name="recommendation" id="" cols="90" rows="10" required></textarea>
        </div>

        <div class="form-group mb-4 text-center">
            <button type="submit" class="btn btn-primary mx-4 px-5" name="insertCaseFA">Submit</button>
        </div>
        </form>
        </div>
    </div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Seperated</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
Seperated
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Married</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        (Copy/Edit)
        <?php $value = '(NAME) is a native resident of Obando, Bulacan. He/She is living with her common law husband/wife for almost (year) year and blessed to have (number of children) children. They live in their own house made of wooden materials. The family is too minimal to support their basic needs and the financial expenses of the client. Thus, they sought MSWDO for proper intervention.' ?>
        <textarea name="recommendation" id="" cols="60" rows="10" required><?= $value ?></textarea>
      </div>
      <div class="modal-footer">
        

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

   


<!-- Data table -->
<script>  
$('table').DataTable();  
</script>

<?php include("misc/footer.html") ?>
